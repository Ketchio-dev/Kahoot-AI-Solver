// Render status and answer suggestions in the bottom-right corner.

const ANSWER_STYLES = {
    red: { color: '#C0392B', icon: '▲' },
    triangle: { color: '#C0392B', icon: '▲' },
    blue: { color: '#2980B9', icon: '◆' },
    diamond: { color: '#2980B9', icon: '◆' },
    yellow: { color: '#F1C40F', icon: '●' },
    circle: { color: '#F1C40F', icon: '●' },
    green: { color: '#27AE60', icon: '■' },
    square: { color: '#27AE60', icon: '■' }
};

const INDICATOR_ID = 'kahoot-stealth-indicator';
let indicatorTimer;
let displayMode = 'normal';
let activeRequest;

function removeIndicator() {
    clearTimeout(indicatorTimer);
    const existing = document.getElementById(INDICATOR_ID);
    if (existing) existing.remove();
}

function createIndicator() {
    removeIndicator();
    const indicator = document.createElement('div');
    indicator.id = INDICATOR_ID;
    indicator.setAttribute('role', 'status');
    indicator.className = displayMode === 'stealth' ? 'kahoot-stealth-indicator' : 'kahoot-normal-panel';
    document.body.appendChild(indicator);
    return indicator;
}

function showProcessing() {
    const indicator = createIndicator();
    indicator.classList.add('kahoot-stealth-indicator--pending');
    indicator.textContent = displayMode === 'stealth' ? '' : 'Analyzing question…';
    // The worker can be interrupted without delivering a result or error.
    indicatorTimer = setTimeout(() => {
        showError('The request timed out or was interrupted. Try again.');
    }, 30000);
}

function showAnswer(answer) {
    const indicator = createIndicator();
    let text;
    if (typeof answer === 'string') {
        const style = ANSWER_STYLES[answer.trim().toLowerCase()];
        if (!style) return showError('Invalid answer.');
        if (displayMode === 'stealth') {
            indicator.style.backgroundColor = style.color;
            if (style.icon === '●') indicator.style.color = '#24160d';
            text = style.icon;
        } else {
            indicator.style.borderInlineStartColor = style.color;
            text = `${style.icon} ${answer.toUpperCase()}`;
        }
    } else if (answer.type === 'multiple') {
        text = answer.colors.map(color => ANSWER_STYLES[color]?.icon || '?').join(' ');
        if (displayMode !== 'stealth') text = `Select all: ${text}\n${answer.colors.join(', ')}`;
    } else if (answer.type === 'text') {
        text = answer.text;
    } else if (answer.type === 'number') {
        text = String(answer.value);
    } else if (answer.type === 'order') {
        text = answer.items.map((item, i) => `${i + 1}. ${item}`).join('\n');
    } else {
        text = `Cannot determine: ${answer.message || 'Missing information'}`;
    }
    indicator.textContent = text;
    if (displayMode === 'stealth' && typeof answer !== 'string') indicator.classList.add('kahoot-stealth-detail');
    indicatorTimer = setTimeout(removeIndicator, displayMode === 'stealth' ? 8000 : 15000);
}

function showError(message) {
    console.warn('Kahoot AI error:', message);
    const indicator = createIndicator();
    indicator.className = 'kahoot-normal-panel';
    indicator.style.borderInlineStartColor = '#ff8794';
    indicator.textContent = `Error: ${message}`;
    indicator.title = message;

    indicatorTimer = setTimeout(removeIndicator, 8000);
}

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action === 'prepare_capture') {
        activeRequest = request.requestId;
        removeIndicator();
        sendResponse(true);
        return;
    }
    if (request.requestId !== activeRequest) return;

    // Messages from older workers/tests without a mode retain compact feedback.
    displayMode = request.mode === 'normal' ? 'normal' : 'stealth';
    if (request.action === 'show_processing') {
        showProcessing();
        sendResponse?.(true);
    } else if (request.action === 'highlight_answer') {
        if (request.answer) {
            showAnswer(request.answer);
        } else {
            showError('The AI could not identify the answer.');
        }
        sendResponse?.(true);
    } else if (request.action === 'error') {
        showError(request.message);
    }
});
